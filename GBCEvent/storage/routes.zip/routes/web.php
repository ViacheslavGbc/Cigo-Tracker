<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/callcreate', 'EventController@callcreate')->middleware('verified');
Route::get('/profile', 'EventController@profile')->middleware('verified');
Route::get('/dashboard', 'EventController@dashboard')->middleware('verified');

Route::get('/', 'HomeController@welcome');

Route::post('/create','EventController@create')->middleware('verified');
Route::get('/viewrec/{id}', 'EventController@viewrec');
Route::get('/editrec/{id}', 'EventController@editrec')->middleware('verified');
Route::post('/update/{id}', 'EventController@update')->middleware('verified');
Route::get('/delete/{id}', 'EventController@delete')->middleware('verified');
Route::get('/refuse/{id}', 'EventController@refuse')->middleware('verified');
Route::get('/refuse_res/{id}/{reason_id}', 'EventController@refuse_res')->middleware('verified');

Route::post('/subscribe/{event_id}/{user_id}', 'EventController@subscribe')->middleware('verified');
Route::get('/allowEvent/{event_id}', 'EventController@allowEvent')->middleware('verified');

Route::get('/makeOwner/{user_id}', 'UserController@makeOwner')->middleware('verified');


Auth::routes(['verify' => true]);

Route::get('/home', 'HomeController@index')->name('home');
Route::post('/comments/store', 'CommentController@store')->name('comment.add');
Route::post('/reply/store', 'CommentController@replyStore')->name('reply.add');

Route::get('/uploadfile', 'UploadFileController@index')->middleware('verified');
Route::post('uploadfile', 'UploadFileController@upload')->middleware('verified');

Route::get('/file/download/{id}/{name}', 'UploadFileController@show');//->name('downloadfile');
