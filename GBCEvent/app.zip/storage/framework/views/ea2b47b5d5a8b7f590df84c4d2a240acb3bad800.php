<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-9 offset-1">

                <div class="card-header h2" align="center">
                    Upcoming Events
                </div>
                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    <table class = "table table-hover">
                            <thead>
                                <th>Title</th>
                                <th>Owner</th>
                                <th>Dates</th>
                                <th>Location</th>
                                <th>Description</th>
                                <th>Actions</th>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                                <tr>
                                    <td><a href="https://w9team1.gblearn.com/GBCEvent/public/viewrec/<?php echo e($event->id); ?>"><?php echo e($event->eventName); ?></a></td>
                                    <td><?php echo e($event->eventOwner); ?></td>
                                    <td><?php echo e($event->eventDate1); ?>,&nbsp;&nbsp;<?php echo e($event->eventDate2); ?></td>
                                    <td><?php echo e($event->eventLocation); ?></td>
                                    <td><?php echo e($event->eventDescription); ?></td>
                                    <td>
                                        <a href="https://w9team1.gblearn.com/GBCEvent/public/editrec/<?php echo e($event->id); ?>">Edit</a>
                                        |
                                        <a href="https://w9team1.gblearn.com/GBCEvent/public/delete/<?php echo e($event->id); ?>">Delete</a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                          <br>
                    
                        <div class="col-6 offset-4">
                            <?php echo e($events->links()); ?>

                        </div>
                </div>
               </div>
                <a href="https://w9team1.gblearn.com/GBCEvent/public/callcreate"><button class="btn btn-success">Create New Event</button></a>
        </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>