<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="panel panel-default">
                    <div class="panel-heading">

                        <div class="panel-heading"><h2>&nbsp&nbsp&nbsp&nbsp Create Event:</h2></div><br/>
                        <form action="/create" method="post">

                            <label> Event Manager</label>&nbsp&nbsp&nbsp
                            <input type="text" name="eventOwner" value="Some Owner"><br /><br>
                            <label> Full Event Title </label>&nbsp&nbsp&nbsp
                            <input type="text" name="eventName" value="Master-Class"><br /><br>
                            <label> Dates & time </label>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
                            <input type="text" name="eventDate1" value="Wed., January 2, 12:00pm">&nbsp&nbsp&nbsp&nbsp
                            <input type="text" name="eventDate2" value="Th., January 3, 2:00pm"><br /><br>
                            <label> Location& room </label>&nbsp&nbsp
                            <input type="text" name="eventLocation" value="GBC Casa-Loma campus, C418"><br /><br>
                            <label> Max. participants </label>
                            <input type="text" name="maxNumParticipants" value="100"><br /><br>
                            <label> Detailed descript.</label>
                            <input type="text" name="eventDescription" value="Unexpectedly sharp and bright seminar"><br /><br>

                            <?php echo e(csrf_field()); ?>

                            <a href="/home"><button>Reset</button></a>&nbsp&nbsp&nbsp&nbsp

                            <input type="submit" name="Submit" value="Add record">
                        </form>

                    </div>

                    <br />
                    <hr>
                    <br />


                </div>
                    <div class="panel-heading"><h2>Upcoming events:</h2></div>
                    <div class="panel-body">
                            <?php if(session('status')): ?>
                                <div class="alert alert-success">
                                    <?php echo e(session('status')); ?>

                                </div>
                            <?php endif; ?>
                          <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <table class = "table table-hover">
                                <thead>
                                <tr>
                                    <th><?php echo e($event->eventDate1); ?></th>
                                    <th><a href="/viewrec/<?php echo e($event->id); ?>"><?php echo e($event->eventOwner); ?></a></th>
                                </tr>
                                </thead>
                                    <tr>
                                        <td></td>
                                        <td><?php echo e($event->eventName); ?></td>
                                        <td>
                                            <a href="/editrec/<?php echo e($event->id); ?>">Edit</a>
                                            |
                                            <a href="/delete/<?php echo e($event->id); ?>">Delete</a>
                                        </td>
                                    </tr>
                            </table>
                              <br>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php echo e($events->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>