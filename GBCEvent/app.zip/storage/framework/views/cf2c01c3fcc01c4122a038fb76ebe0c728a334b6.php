<?php $__env->startSection('content'); ?>

<script src="https://kit.fontawesome.com/bb250377d6.js" crossorigin="anonymous"></script>

    <div class="container">
        <div class="row">
            <div class="col-md-9 offset-1">

                <div class="card-header h2" align="center">
                    Welcome Home!<!--Upcoming Events-->
                </div>
                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    <table class = "table table-hover">
                            <thead>
                                <th>Title</th>
                                <th>Owner</th>
                                <th>Date 1</th>
                                <th>Date 2</th>
                                <th>Location</th>
                                <th>Description</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(Auth::user()->id == $event->created_by ): ?>  <!-- owner only can see her or his events-->
                                        <tr>
                                            <td><a href="/viewrec/<?php echo e($event->id); ?>"><?php echo e($event->eventName); ?></a></td>
                                            <td><?php echo e(Auth::user()->name); ?>&nbsp;<?php echo e(Auth::user()->lname); ?></td>
                                            <td><?php echo e($event->eventDate1); ?>,&nbsp;&nbsp;<?php echo e($event->eventTime1); ?></td>
                                            <td><?php echo e($event->eventDate2); ?>,&nbsp;&nbsp;<?php echo e($event->eventTime2); ?></td>
                                            <td><?php echo e($event->eventLocation); ?>, <?php echo e($event->eventRoom); ?></td>
                                            <td><?php echo e($event->eventDescription); ?></td>
                                            <td>
                                            <?php if($event->status_enabled > 2): ?> 
                                                <span class="text-danger">Blocked / 
                                                <?php if($event->status_enabled == 3): ?>
                                                    Descrimination issue
                                                <?php endif; ?>
                                                <?php if($event->status_enabled == 4): ?>
                                                    Scope issue
                                                <?php endif; ?>
                                                <?php if($event->status_enabled == 5): ?>
                                                    Not Legal 
                                                <?php endif; ?>
                                                <?php if($event->status_enabled == 6): ?>
                                                    Contact college administration for details
                                                <?php endif; ?>
                                                <?php if($event->status_enabled == 7): ?>
                                                    Date, Time  or Location adjustment required 
                                                <?php endif; ?>
                                                </span>
                                            <?php else: ?>
                                                <span class="text-success">Enabled</span>
                                            <?php endif; ?>
                                            </td>
                                           
                                           <?php if(Auth::user()->user_type > 1): ?> <!-- not an owner or admin logged in? No access!-->
                                            <td>
                                                <a href="/editrec/<?php echo e($event->id); ?>">Edit</a>
                                                |
                                                <a onclick="return myFunction();"href="/delete/<?php echo e($event->id); ?>">Delete</a>

                                                <script>
                                                    function myFunction() {
                                                        if(!confirm("Are you sure to delete this event?"))
                                                            event.preventDefault();
                                                    }
                                                </script>
                                                |
                                                <a href="">View Report</a>
                                            </td>
                                           <?php endif; ?>
                                        </tr>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                          <br>

                        <div class="col-6 offset-4">
                            <?php echo e($events->links()); ?>

                        </div>

                </div>
               </div>
            <?php if(Auth::user()->user_type > 1): ?> <!-- not an owner or admin logged in? No access! -->
                <a href="/callcreate"><button class="btn btn-success new"><i class="fas fa-plus"></i></button></a>
                <a href="/profile"><button class="btn btn-success"> <i class="far fa-calendar-alt"></i>&nbsp;My Events </button></a>
                <?php if(Auth::user()->user_type > 2): ?> <!-- Hi, Maziar!  -->
                    <a href="/dashboard"><button class="btn btn-success"> Dashboard </button></a>
                <?php endif; ?>
                <p>New events will be displayed to users after approval</p>
            <?php endif; ?>
        </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>