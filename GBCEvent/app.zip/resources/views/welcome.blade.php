<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>GBCEvents</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet" type="text/css">

        <!-- Styles -->
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
        <link href="{{ asset('css/app.css') }}" rel="stylesheet">
        <link rel="shortcut icon" type="image/ico" href="favicon.ico"/>
         <script src="https://kit.fontawesome.com/bb250377d6.js" crossorigin="anonymous"></script>

        <style>
            body{
                background-color: #d4d8f9;
            }
            .navbar{
                background-color: #e0e3f9;
            }
        </style>

    </head>

    <body>

        <div id="app">
<nav class="navbar navbar-expand-md navbar-light navbar-laravel">

              

                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <table>
                     <th><td>    
           
                        <!-- Left Side Of Navbar -->
                        <ul class="navbar-nav mr-auto">
                            <li class="nav-item">
                                <div class="navbar_brand">
                                    </br>
                                    <a href="{{ url('/') }}"><img src="{{ URL::asset('images/Logo1.jpg') }}"/> 
                     </td><td>               
                                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <img src="{{ URL::asset('images/Brussels107Banner.jpg') }}"/></a>
                                    </br>
                     </td><td>                
                                </div>
                            </li>
                        </ul>
                        <!-- Right Side Of Navbar -->
                        <ul class="navbar-nav ml-auto">
                @if (Route::has('login'))
                        @auth
                            <li class="nav-item">
                                <a class="nav-link" href="{{ url('/home') }}">Home</a>
                            </li>
                            @else
                                <li class="nav-item">
                                    <a class="nav-link" href="{{ route('login') }}">Login</a>
                                </li>
                                @if (Route::has('register'))
                                    <li class="nav-item">
                                        <a class="nav-link" href="{{ route('register') }}">Register</a>
                                    </li>
                                @endif
                        @endauth
                        </ul>
                     </td></th></table>
                    
                    </div>
                @endif
            </nav>




            <div class="container">
                <div class="row">
                    <div class="col-md-8 offset-2">
                        <div class="card">
                            <div class="card-header h2" align="center"><i class="far fa-calendar-alt"></i>&nbsp;Upcoming Events
                            </div>
                            <div class="card-header h2">
                                    <form class="navbar-form navbar-left form-inline" action="/action_page.php">
                                          <div class="form-group">
                                            <input type="text" class="form-control" placeholder="Type search creteria here">
                                          </div>
                                        <button type="submit" class="btn btn-success">Search</button>
                                        <!-- if (txtValue.toUpperCase().indexOf(filter) > -1) {  <-something like this  -->
                                    </form>
                            </div>
                            
                           
                            
                            </div>
                                <div class="card-body">
                                    @if (session('status'))
                                        <div class="alert alert-success">
                                            {{ session('status') }}
                                        </div>
                                    @endif
                                  
                                    <table class = "table table-striped table table-bordered table table-hover">
                                        
                                             <thead class="table-active">
                                            <th>Title</th>
                                            <th>Owner</th>
                                            <th>Date 1</th>
                                            <th>Date 2</th>
                                            <th>Location</th>
                                            <th>Description</th>

                                            </thead>
                                            <tbody>
                                            @foreach($events as $event)
                                              @if ($event->status_enabled > 0 AND $event->status_enabled < 3)  <!-- if event is approved by admin - display it ! -->
                                                <tr>
                                                    <td><a href="/viewrec/{{$event->id}}">{{$event->eventName}}</a></td>
                                                    <td>{{$event->eventOwner}}</td>
                                                    <td>{{$event->eventDate1}},&nbsp;&nbsp;</br>{{$event->eventTime1}}</td>
                                                    <td>{{$event->eventDate2}},&nbsp;&nbsp;</br>{{$event->eventTime2}}</td>
                                                    <td>{{$event->eventLocation}}, {{$event->eventRoom}}</td>
                                                    <td>{{$event->eventDescription}}</td>
                                                </tr>
                                              @endif
                                             @endforeach
                                            </tbody>
                                        </table>
                                        <br>
                                        <div class="col-6 offset-4">
                                            {{$events->links()}}  <!-- Pagination -->
                                        </div>
                                       
                                </div>
                                   

                            </div>
                                        <div class="col-2">
                                            <img src="{{ URL::asset('images/banner.png') }}"/>
                                        </div> 
                        </div>
                    </div>
                </div>
                </div>
        </div>
    </body>
</html>
